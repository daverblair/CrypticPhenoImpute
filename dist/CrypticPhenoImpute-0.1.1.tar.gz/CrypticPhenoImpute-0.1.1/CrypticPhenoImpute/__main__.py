from .CrypticPhenoImpute import main
main()
